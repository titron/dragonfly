These are new drawings of the recently-announced Open Source Hardware logo. They are intended to be used as PCB silkscreen decoration for open source hardware designs, using the Kicad EDA tools.

Drawn and released by Wayne and Layne, LLC
