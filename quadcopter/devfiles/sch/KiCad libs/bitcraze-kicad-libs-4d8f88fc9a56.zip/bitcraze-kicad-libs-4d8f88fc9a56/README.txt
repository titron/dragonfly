This repo contains custom components and footprints.

Footprints:
 LQFP48

Components:
 mcu-st:
  STM32F100XX
 mcu-nxp:
  LPC1769FBD100
 regulators:
  TLV1117-33IDCY
 audio-vlsi:
  ...

